package com.safetymap.safetymap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafetyMapApplicationTests {

    @Test
    void contextLoads() {
    }

}
